INSERT INTO Authors (author_name) VALUES ('John Doe');
SELECT * FROM Authors;
SELECT * FROM Authors WHERE id = 1;
UPDATE Authors SET author_name = 'Jane Doe' WHERE id = 1;
DELETE FROM Authors WHERE id = 1;
INSERT INTO Categories (category_name) VALUES ('Technology');

SELECT * FROM Categories;
SELECT * FROM Categories WHERE id = 1;
UPDATE Categories SET category_name = 'Science' WHERE id = 1;
DELETE FROM Categories WHERE id = 1;
INSERT INTO Blogs (title, body, category_id, author_id) 
VALUES ('My First Blog', 'This is the content of my first blog.', 1, 1);
SELECT * FROM Blogs;
SELECT * FROM Blogs WHERE id = 1;
SELECT 
    b.*, c.category_name, a.author_name 
FROM 
    Blogs b 
JOIN 
    Categories c ON b.category_id = c.id 
JOIN 
    Authors a ON b.author_id = a.id;
    UPDATE Blogs SET title = 'Updated Blog Title' WHERE id = 1;
    DELETE FROM Blogs WHERE id = 1;
    SELECT * FROM Blogs WHERE author_id = 1;
    SELECT * FROM Blogs WHERE category_id = 1;
    UPDATE Blogs SET title = 'Updated Blog Title' WHERE id = 1;
    UPDATE Blogs SET category_id = 2, author_id = 2 WHERE id = 1;
    DELETE FROM Blogs WHERE id = 1;
    SELECT * FROM Blogs WHERE author_id = 1;
    SELECT * FROM Blogs WHERE category_id = 1;
